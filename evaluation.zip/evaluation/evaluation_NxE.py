import requests
import argparse
import json

def data_reader(filePath):
    data = []
    with open(filePath, 'r') as f:
        for line in f:
            strippedLine = line.strip()
            ip = strippedLine.split('  :  (\'')[1].split('\',')[0]
            data.append(ip)
    return data

def GET_request(ip, threatDict):

    if ip not in threatDict.keys():
        url = "https://www.badips.com/get/info/{0}".format(ip)

        payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"ip\"\r\n\r\n{0}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--".format(ip)
        headers = {
            'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
            'Cache-Control': "no-cache",
            'Postman-Token': "893ca84d-53b9-e11d-09b9-59894c2b5270"
        }
        response = requests.request("GET", url, data=payload, headers=headers)
        responseDict = json.loads(response.text)
        try:
            result = responseDict['Listed']
        except KeyError:
            result = False
        threatDict[ip] = result
    else:
        result = threatDict[ip]

    return result, threatDict

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='print stat of source entropy')
    parser.add_argument('--file', type=str, default='NxE_sorted')
    parser.add_argument('--threatJson', type=str, default='threat.json')
    args = parser.parse_args()
    ip_data = data_reader(args.file)
    try:
        with open(args.threatJson, 'r') as f:
            threatDict = json.load(f.read())
    except:
        threatDict = {}
    totalThreatIp = 0
    for ip in ip_data[0:100]:
        try:
            result, threatDict = GET_request(ip, threatDict)
        except:
            continue
        print(ip, result)
        if result:
            totalThreatIp += 1
    print("total threat ip num: {0}".format(totalThreatIp))
    with open(args.threatJson, 'w') as f:
        jsonStr = json.dumps(threatDict)
        f.write(jsonStr)
