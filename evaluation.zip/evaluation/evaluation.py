import requests
import argparse
import json

def data_reader(filePath):
    data = []
    with open(filePath, 'r') as f:
        for line in f:
            strippedLine = line.strip()
            ip = strippedLine.split(' : ')[1]
            data.append(ip)
    return data

def GET_request(ip, threatDict):

    if ip not in threatDict.keys():
        url = "https://www.badips.com/get/info/{0}".format(ip)

        payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"ip\"\r\n\r\n{0}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--".format(ip)
        headers = {
            'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
            'Cache-Control': "no-cache",
            'Postman-Token': "893ca84d-53b9-e11d-09b9-59894c2b5270"
        }
        response = requests.request("GET", url, data=payload, headers=headers)
        responseDict = json.loads(response.text)
        try:
            result = responseDict['Listed']
        except KeyError:
            result = False
        threatDict[ip] = result
    else:
        result = threatDict[ip]

    return result, threatDict

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='print stat of source entropy')
    parser.add_argument('--file', type=str, default='Entropy_netflow_Apr7-May7')
    parser.add_argument('--threatJson', type=str, default='threat.json')
    args = parser.parse_args()
    ip_data = data_reader(args.file)
    try:
        with open(args.threatJson, 'r') as f:
            threatDict = json.load(f.read())
    except:
        threatDict = {}
    total = len(ip_data)
    for i in range(total):
        ip = ip_data[i]
        try:
            result, threatDict = GET_request(ip, threatDict)
        except:
            continue
        if i % 1000 == 0:
            print("{0}/{1} done".format(i, total))
            with open(args.threatJson, 'w') as f:
                jsonStr = json.dumps(threatDict)
                f.write(jsonStr)


    with open(args.threatJson, 'r') as f:
        threatDict = json.load(f.read())
        totalThreatIp = len(threatDict)

    print("total threat ip num: {0}".format(totalThreatIp))
